exports.clickreports = async (session, models, vars) => {
    await session.transform.kdgapp1.action('landingpage', 'clickreports');
};