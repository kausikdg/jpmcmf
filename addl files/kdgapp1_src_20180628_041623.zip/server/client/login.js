exports.submit = async (session, models, vars) => {
    await session.transform.kdgapp1.update('login', models.login);
    await session.transform.kdgapp1.action('login', 'submit');
};