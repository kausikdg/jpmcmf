exports.logout = async (session, models, vars) => {
    await session.transform.kdgapp1.update('home', models.home);
    await session.transform.kdgapp1.action('home', 'logout');
};