const session = require('smartux-connect');
session.transform.kdgapp1 = session.loadTransform('kdgapp1');
require('./client');
require('./transform/kdgapp1/login');
require('./transform/kdgapp1/landingpage');
require('./transform/kdgapp1/home');
session.start();