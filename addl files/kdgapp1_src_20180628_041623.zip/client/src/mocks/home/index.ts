export let mock_home = {
    logout: function logout(params) {
        this.go("login");
    }
};
