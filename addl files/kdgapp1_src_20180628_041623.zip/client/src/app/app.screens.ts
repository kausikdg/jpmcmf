/***  Generated file, do not change.  */
import { MenuComponent } from './menu/menu';
import { login_PhonePortrait } from '../pages/login/PhonePortrait/login';
import { home_PhonePortrait } from '../pages/home/PhonePortrait/home';
import { summary_PhonePortrait } from '../pages/summary/PhonePortrait/summary';
import { createissue_PhonePortrait } from '../pages/createissue/PhonePortrait/createissue';
export class Screens {
  static declarations = [
    MenuComponent,
    login_PhonePortrait,
    home_PhonePortrait,
    summary_PhonePortrait,
    createissue_PhonePortrait
  ];
  static mapping = {
    'login': {
      PhonePortrait: login_PhonePortrait
    },
    'home': {
      PhonePortrait: home_PhonePortrait
    },
    'summary': {
      PhonePortrait: summary_PhonePortrait
    },
    'createissue': {
      PhonePortrait: createissue_PhonePortrait
    }
  }
}