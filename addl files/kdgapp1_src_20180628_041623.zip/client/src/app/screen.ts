import { BaseScreen } from 'smartux-client';

export class Screen extends BaseScreen {
}
