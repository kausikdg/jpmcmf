import { Component } from '@angular/core';
import { Screen } from 'app/screen';

declare var window: any;

@Component({
    selector: 'screen-home-phoneportrait',
    templateUrl: 'home.html'
})
export class home_PhonePortrait extends Screen {
    data: any;

    ngOnInit(): void {
        super.ngOnInit();
        // Logic to run when the screen loads goes here.
    }

    ngOnDestroy(): void {
        super.ngOnDestroy();
        // Logic to run when the screen unloads goes here.
    }

    onDataLoad(data: any): void {
        // Logic to run when the screen's data is updated goes here.
        //var foo = data.approvallist.map(a => { return { 'kausik': a.name, 'count': 0 } });
        var foo = data.approvallist.map(a => a.name);
        foo = foo.filter((v, i, a) => a.indexOf(v) === i);
        var bar = {};
        foo.forEach(i => bar[i] = 0);
        data.approvallist.forEach(i => bar[i.name] += 1);
        var final = [];
        Object.keys(bar).forEach(i => final.push({ 'Name': i, 'Count': bar[i] }));
        data.foo = data.approvallist.filter(bar => bar.name === final[2].Name);
    }
}
