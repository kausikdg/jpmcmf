import { Component } from '@angular/core';
import { Screen } from 'app/screen';

@Component({
  selector: 'screen-createissue-phoneportrait',
  templateUrl: 'createissue.html'
})
export class createissue_PhonePortrait extends Screen {
  data: any;

  ngOnInit(): void {
    super.ngOnInit();
    // Logic to run when the screen loads goes here.
  }

  ngOnDestroy(): void {
    super.ngOnDestroy();
    // Logic to run when the screen unloads goes here.
  }

  onDataLoad(data: any): void {
    // Logic to run when the screen's data is updated goes here.
      data.Tickets = [];
      this.data.Tickets.push(JSON.parse(JSON.stringify({ 'issueTypes': this.data.issueTypesMeta, 'issueSubTypes': [] })));
  }

  toggleSubtypeSelected(item: any): void {
      item.subtypeSelected = !item.subtypeSelected;
  }

  typeSelected(selectedType: any, index: any): void {
      for (var i = 0; i < this.data.issuesSubtypesMeta.length; i++) {
          if (this.data.issuesSubtypesMeta[i].type === selectedType) {
              this.data.Tickets[index].issueSubtypes = JSON.parse(JSON.stringify(this.data.issuesSubtypesMeta[i].subtypes));
              break;
          }
      }
  }

  addTicket(): void {
      this.data.Tickets.unshift(JSON.parse(JSON.stringify({ 'issueTypes': this.data.issueTypesMeta, 'issueSubTypes': [] })));
  }
}
