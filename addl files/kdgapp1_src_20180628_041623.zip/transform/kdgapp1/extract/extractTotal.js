exports = function (node) {
    return node.split('$')[1];
}